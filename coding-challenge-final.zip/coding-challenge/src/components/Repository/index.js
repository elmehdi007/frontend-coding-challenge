export { default } from "./Repository";
